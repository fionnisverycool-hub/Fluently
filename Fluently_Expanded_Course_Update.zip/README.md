# Fluently — beginner language-learning app

Fluently is a React + TypeScript + Vite prototype for language learning, with Gub the customizable mascot.

## Run on Windows

1. Extract the downloaded ZIP completely.
2. Open the **fluently** folder — the one that contains `package.json` directly.
3. Click the File Explorer address bar, type `cmd`, and press Enter.
4. Run these commands one at a time:

   ```bat
   npm.cmd install
   npm.cmd run dev
   ```

5. Open the local URL Vite prints (usually `http://localhost:5173`).

## What's included

- Five beginner courses: Spanish, French, German, Japanese, and English.
- Seven progressive units per language, with seven lessons in each unit (49 lessons per course).
- The first lesson starts with pronunciation, followed by greetings and basic vocabulary, pronouns, numbers, everyday objects, simple sentences, food, directions, and time words.
- Language-specific words, pronunciation hints, speech playback, questions, and independent progress for each course.
- A vertical lesson path with locked, current, and completed lesson states.
- Five hearts maximum; incorrect answers spend a heart, and one heart recharges every hour. The timer continues while the app is closed because the recharge is based on saved timestamps.
- Animated lesson/unit celebration screens, lesson entrance motion, progress bars, XP, daily practice prompt, hints, and achievements.
- Character customization: choose a mascot style, scarf colour, and accessory.
- Dark mode, language selector, progress overview, and local browser storage.

## Notes

This is a local prototype. Progress and customization are stored in the browser on the current device. Accounts, cloud sync, and server-backed features are not included. Pronunciation spellings are beginner-friendly approximations; the browser's speech playback depends on installed system voices.
