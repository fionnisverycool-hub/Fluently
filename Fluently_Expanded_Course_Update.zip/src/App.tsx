import { useEffect, useMemo, useState } from 'react'
import {
  Home, Map, BarChart3, UserRound, Settings, Flame, Heart, Zap,
  ChevronRight, LockKeyhole, Check, Sparkles, BookOpen, Volume2, X,
  CircleHelp, RotateCcw, Languages, Target, Star, Play, ShieldCheck,
  Award, Clock3, WandSparkles
} from 'lucide-react'

type Page = 'Home' | 'Learn' | 'Progress' | 'Profile' | 'Settings'
type Lang = { name: string; flag: string; greeting: string; course: string; speechCode: string }
type Term = { term: string; pronunciation: string }
type QuestionKind = 'pronunciation' | 'meaning' | 'term'
type Question = { prompt: string; options: string[]; answer: string; explain: string; say: string }
type CourseProgress = { completed: number; xp: number; correct: number; answered: number; lastPracticeDate: string }
type AppState = {
  language: string
  hearts: number
  lastHeartAt: number
  courses: Record<string, CourseProgress>
  character: string
  scarfColor: string
  accessory: string
}

const HEART_MAX = 5
const HEART_INTERVAL = 60 * 60 * 1000
const LESSONS_PER_SECTION = 7
const TOTAL_LESSONS = 49

const languages: Lang[] = [
  { name: 'Spanish', flag: '🇪🇸', greeting: '¡Hola!', course: 'Spanish for beginners', speechCode: 'es-ES' },
  { name: 'French', flag: '🇫🇷', greeting: 'Bonjour!', course: 'French for beginners', speechCode: 'fr-FR' },
  { name: 'German', flag: '🇩🇪', greeting: 'Hallo!', course: 'German for beginners', speechCode: 'de-DE' },
  { name: 'Japanese', flag: '🇯🇵', greeting: 'こんにちは', course: 'Japanese for beginners', speechCode: 'ja-JP' },
  { name: 'English', flag: '🇬🇧', greeting: 'Hello!', course: 'English for beginners', speechCode: 'en-US' },
]

const sections = [
  {
    title: 'Sound & first words', subtitle: 'Start with pronunciation, then learn your first useful words.', icon: '🔤',
    titles: ['Hello: pronunciation', 'Your first greeting', 'Say yes', 'Say no', 'Please', 'Thank you', 'Goodbye'],
    subtitles: ['Hear the sounds slowly', 'A friendly greeting', 'A positive answer', 'A negative answer', 'Ask politely', 'Show gratitude', 'End a conversation'],
  },
  {
    title: 'People & introductions', subtitle: 'Learn the words that help you talk about yourself and others.', icon: '👋',
    titles: ['I / me', 'You', 'We', 'They', 'Friend', 'Family', 'Name'],
    subtitles: ['Talk about yourself', 'Speak to one person', 'Include yourself and others', 'Talk about a group', 'People you know', 'People close to you', 'Ask or share a name'],
  },
  {
    title: 'Numbers 1–7', subtitle: 'Build confidence counting one small step at a time.', icon: '🔢',
    titles: ['Number one', 'Number two', 'Number three', 'Number four', 'Number five', 'Number six', 'Number seven'],
    subtitles: ['Count one', 'Count two', 'Count three', 'Count four', 'Count five', 'Count six', 'Count seven'],
  },
  {
    title: 'Things around you', subtitle: 'Name familiar things you see at home and at school.', icon: '🏡',
    titles: ['Water', 'Food', 'Book', 'Home', 'School', 'Cat', 'Dog'],
    subtitles: ['A drink you need', 'Something you eat', 'Something to read', 'Where you live', 'A place to learn', 'A small furry pet', 'A common pet'],
  },
  {
    title: 'Tiny sentences', subtitle: 'Turn single words into little conversations.', icon: '💬',
    titles: ['I am…', 'How are you?', 'I’m fine', 'What is your name?', 'My name is…', 'I like it', 'I don’t understand'],
    subtitles: ['Introduce yourself', 'Ask how someone feels', 'Say you are okay', 'Ask someone’s name', 'Tell someone your name', 'Share something you like', 'Ask for help'],
  },
  {
    title: 'Food & polite requests', subtitle: 'Talk about snacks, drinks, and what you need.', icon: '🍎',
    titles: ['Apple', 'Bread', 'Rice', 'Milk', 'Coffee', 'I’m hungry', 'Water, please'],
    subtitles: ['Name a fruit', 'A baked food', 'A meal-time staple', 'A drink', 'A hot drink', 'Say you want food', 'Make a polite request'],
  },
  {
    title: 'Places & time', subtitle: 'Use simple location words and talk about today and tomorrow.', icon: '🧭',
    titles: ['Where?', 'Here', 'There', 'Left', 'Right', 'Today', 'Tomorrow'],
    subtitles: ['Ask about a place', 'A place near you', 'A place farther away', 'One direction', 'The other direction', 'The current day', 'The next day'],
  },
]

const englishMeanings = [
  ['Hello', 'Hello', 'Yes', 'No', 'Please', 'Thank you', 'Goodbye'],
  ['I / me', 'You', 'We / us', 'They / them', 'Friend', 'Family', 'Name'],
  ['One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven'],
  ['Water', 'Food', 'Book', 'Home / house', 'School', 'Cat', 'Dog'],
  ['I am…', 'How are you?', 'I am fine', 'What is your name?', 'My name is…', 'I like it', 'I do not understand'],
  ['Apple', 'Bread', 'Rice', 'Milk', 'Coffee', 'I am hungry', 'Water, please'],
  ['Where?', 'Here', 'There', 'Left', 'Right', 'Today', 'Tomorrow'],
]

const englishDefinitions = [
  ['A friendly greeting', 'A friendly greeting', 'A positive answer', 'A negative answer', 'A polite word for requests', 'Words that show gratitude', 'A way to say farewell'],
  ['The speaker', 'The person being spoken to', 'The speaker and other people', 'People or things being spoken about', 'A person you know and like', 'People related to you or close to you', 'What a person is called'],
  ['The number after zero', 'The number after one', 'The number after two', 'The number after three', 'The number after four', 'The number after five', 'The number after six'],
  ['A drink your body needs', 'Something you eat', 'Something with pages to read', 'The place where you live', 'A place for learning', 'A pet that says meow', 'A pet that often barks'],
  ['Telling someone who you are', 'Asking about someone’s wellbeing', 'Saying you feel okay', 'Asking for a person’s name', 'Telling someone your name', 'Saying something is enjoyable', 'Saying you do not understand'],
  ['A fruit', 'A food baked from flour', 'Small grains often eaten as a meal', 'A drink made from milk or a substitute', 'A hot drink', 'Saying you want food', 'A polite way to ask for water'],
  ['Asking about a location', 'A location near the speaker', 'A location away from the speaker', 'The direction opposite right', 'The direction opposite left', 'The current day', 'The day after today'],
]

// Each language has its own 49-word beginner course. The pronunciation guide is a simple reading aid.
const courseTerms: Record<string, Term[][]> = {
  Spanish: [
    [{term:'Hola',pronunciation:'OH-lah'},{term:'Hola',pronunciation:'OH-lah'},{term:'Sí',pronunciation:'see'},{term:'No',pronunciation:'noh'},{term:'Por favor',pronunciation:'por fah-VOR'},{term:'Gracias',pronunciation:'GRAH-syahs'},{term:'Adiós',pronunciation:'ah-DYOS'}],
    [{term:'yo',pronunciation:'yoh'},{term:'tú',pronunciation:'too'},{term:'nosotros',pronunciation:'noh-SOH-tros'},{term:'ellos',pronunciation:'EH-yos'},{term:'amigo',pronunciation:'ah-MEE-goh'},{term:'familia',pronunciation:'fah-MEE-lee-ah'},{term:'nombre',pronunciation:'NOHM-breh'}],
    [{term:'uno',pronunciation:'OO-noh'},{term:'dos',pronunciation:'dohs'},{term:'tres',pronunciation:'trehs'},{term:'cuatro',pronunciation:'KWAH-troh'},{term:'cinco',pronunciation:'SEEN-koh'},{term:'seis',pronunciation:'says'},{term:'siete',pronunciation:'see-EH-teh'}],
    [{term:'agua',pronunciation:'AH-gwah'},{term:'comida',pronunciation:'koh-MEE-dah'},{term:'libro',pronunciation:'LEE-broh'},{term:'casa',pronunciation:'KAH-sah'},{term:'escuela',pronunciation:'es-KWEH-lah'},{term:'gato',pronunciation:'GAH-toh'},{term:'perro',pronunciation:'PEH-rroh'}],
    [{term:'Soy…',pronunciation:'soy'},{term:'¿Cómo estás?',pronunciation:'KOH-moh ehs-TAHS'},{term:'Estoy bien',pronunciation:'ehs-TOY byen'},{term:'¿Cómo te llamas?',pronunciation:'KOH-moh teh YAH-mahs'},{term:'Me llamo…',pronunciation:'meh YAH-moh'},{term:'Me gusta',pronunciation:'meh GOO-stah'},{term:'No entiendo',pronunciation:'noh en-TYEN-doh'}],
    [{term:'manzana',pronunciation:'mahn-SAH-nah'},{term:'pan',pronunciation:'pahn'},{term:'arroz',pronunciation:'ah-RROHS'},{term:'leche',pronunciation:'LEH-cheh'},{term:'café',pronunciation:'kah-FEH'},{term:'Tengo hambre',pronunciation:'TEN-goh AHM-breh'},{term:'Agua, por favor',pronunciation:'AH-gwah por fah-VOR'}],
    [{term:'¿Dónde?',pronunciation:'DOHN-deh'},{term:'aquí',pronunciation:'ah-KEE'},{term:'allí',pronunciation:'ah-YEE'},{term:'izquierda',pronunciation:'ees-KYER-dah'},{term:'derecha',pronunciation:'deh-REH-chah'},{term:'hoy',pronunciation:'oy'},{term:'mañana',pronunciation:'mah-NYAH-nah'}],
  ],
  French: [
    [{term:'Bonjour',pronunciation:'bohn-ZHOOR'},{term:'Bonjour',pronunciation:'bohn-ZHOOR'},{term:'Oui',pronunciation:'wee'},{term:'Non',pronunciation:'nohn'},{term:'S’il vous plaît',pronunciation:'seel voo PLEH'},{term:'Merci',pronunciation:'mehr-SEE'},{term:'Au revoir',pronunciation:'oh ruh-VWAHR'}],
    [{term:'je',pronunciation:'zhuh'},{term:'tu',pronunciation:'tew'},{term:'nous',pronunciation:'noo'},{term:'ils / elles',pronunciation:'eel / ell'},{term:'ami',pronunciation:'ah-MEE'},{term:'famille',pronunciation:'fah-MEE'},{term:'nom',pronunciation:'nohn'}],
    [{term:'un',pronunciation:'uhn'},{term:'deux',pronunciation:'duh'},{term:'trois',pronunciation:'twah'},{term:'quatre',pronunciation:'KAH-truh'},{term:'cinq',pronunciation:'sank'},{term:'six',pronunciation:'sees'},{term:'sept',pronunciation:'set'}],
    [{term:'eau',pronunciation:'oh'},{term:'nourriture',pronunciation:'noo-ree-TEWR'},{term:'livre',pronunciation:'leevr'},{term:'maison',pronunciation:'meh-ZOHN'},{term:'école',pronunciation:'ay-KOHL'},{term:'chat',pronunciation:'shah'},{term:'chien',pronunciation:'shyen'}],
    [{term:'Je suis…',pronunciation:'zhuh swee'},{term:'Comment ça va ?',pronunciation:'koh-mahn sah VAH'},{term:'Ça va bien',pronunciation:'sah vah BYEHN'},{term:'Comment tu t’appelles ?',pronunciation:'koh-mahn tew tah-PELL'},{term:'Je m’appelle…',pronunciation:'zhuh mah-PELL'},{term:'J’aime ça',pronunciation:'zhem sah'},{term:'Je ne comprends pas',pronunciation:'zhuh nuh kohm-PRAHN pah'}],
    [{term:'pomme',pronunciation:'pohm'},{term:'pain',pronunciation:'pan'},{term:'riz',pronunciation:'ree'},{term:'lait',pronunciation:'leh'},{term:'café',pronunciation:'kah-FAY'},{term:'J’ai faim',pronunciation:'zhay fan'},{term:'De l’eau, s’il vous plaît',pronunciation:'duh LOH seel voo PLEH'}],
    [{term:'où',pronunciation:'oo'},{term:'ici',pronunciation:'ee-SEE'},{term:'là',pronunciation:'lah'},{term:'gauche',pronunciation:'gohsh'},{term:'droite',pronunciation:'drwaht'},{term:'aujourd’hui',pronunciation:'oh-zhoor-DWEE'},{term:'demain',pronunciation:'duh-MAN'}],
  ],
  German: [
    [{term:'Hallo',pronunciation:'HAH-loh'},{term:'Hallo',pronunciation:'HAH-loh'},{term:'Ja',pronunciation:'yah'},{term:'Nein',pronunciation:'nine'},{term:'Bitte',pronunciation:'BIT-uh'},{term:'Danke',pronunciation:'DAHN-kuh'},{term:'Tschüss',pronunciation:'choos'}],
    [{term:'ich',pronunciation:'ikh'},{term:'du',pronunciation:'doo'},{term:'wir',pronunciation:'veer'},{term:'sie',pronunciation:'zee'},{term:'Freund',pronunciation:'froint'},{term:'Familie',pronunciation:'fah-MEE-lee-eh'},{term:'Name',pronunciation:'NAH-muh'}],
    [{term:'eins',pronunciation:'eyens'},{term:'zwei',pronunciation:'tsv-eye'},{term:'drei',pronunciation:'dry'},{term:'vier',pronunciation:'feer'},{term:'fünf',pronunciation:'fewnf'},{term:'sechs',pronunciation:'zeks'},{term:'sieben',pronunciation:'ZEE-ben'}],
    [{term:'Wasser',pronunciation:'VAH-ser'},{term:'Essen',pronunciation:'ESS-en'},{term:'Buch',pronunciation:'bookh'},{term:'Haus',pronunciation:'hows'},{term:'Schule',pronunciation:'SHOO-luh'},{term:'Katze',pronunciation:'KAHT-suh'},{term:'Hund',pronunciation:'hoont'}],
    [{term:'Ich bin…',pronunciation:'ikh bin'},{term:'Wie geht’s?',pronunciation:'vee gayts'},{term:'Mir geht’s gut',pronunciation:'meer gayts goot'},{term:'Wie heißt du?',pronunciation:'vee hyst doo'},{term:'Ich heiße…',pronunciation:'ikh HY-suh'},{term:'Das mag ich',pronunciation:'dahs mahk ikh'},{term:'Ich verstehe nicht',pronunciation:'ikh fer-SHTAY-uh nikht'}],
    [{term:'Apfel',pronunciation:'AHP-fel'},{term:'Brot',pronunciation:'broht'},{term:'Reis',pronunciation:'ryes'},{term:'Milch',pronunciation:'milkh'},{term:'Kaffee',pronunciation:'kah-FAY'},{term:'Ich habe Hunger',pronunciation:'ikh HAH-buh HOONG-er'},{term:'Wasser, bitte',pronunciation:'VAH-ser BIT-uh'}],
    [{term:'Wo?',pronunciation:'voh'},{term:'hier',pronunciation:'heer'},{term:'dort',pronunciation:'dort'},{term:'links',pronunciation:'links'},{term:'rechts',pronunciation:'rekhts'},{term:'heute',pronunciation:'HOY-tuh'},{term:'morgen',pronunciation:'MOR-gen'}],
  ],
  Japanese: [
    [{term:'こんにちは',pronunciation:'kon-nee-chee-wah'},{term:'こんにちは',pronunciation:'kon-nee-chee-wah'},{term:'はい',pronunciation:'hai'},{term:'いいえ',pronunciation:'ee-eh'},{term:'お願いします',pronunciation:'oh-neh-guy-shee-mahs'},{term:'ありがとう',pronunciation:'ah-ree-gah-toh'},{term:'さようなら',pronunciation:'sah-yoh-nah-rah'}],
    [{term:'私',pronunciation:'wah-tah-shee'},{term:'あなた',pronunciation:'ah-nah-tah'},{term:'私たち',pronunciation:'wah-tah-shee-tah-chee'},{term:'彼ら',pronunciation:'kah-reh-rah'},{term:'友だち',pronunciation:'toh-moh-dah-chee'},{term:'家族',pronunciation:'kah-zoh-koo'},{term:'名前',pronunciation:'nah-mah-eh'}],
    [{term:'一',pronunciation:'ee-chee'},{term:'二',pronunciation:'nee'},{term:'三',pronunciation:'sahn'},{term:'四',pronunciation:'yohn'},{term:'五',pronunciation:'goh'},{term:'六',pronunciation:'roh-koo'},{term:'七',pronunciation:'nah-nah'}],
    [{term:'水',pronunciation:'mee-zoo'},{term:'食べ物',pronunciation:'tah-beh-moh-noh'},{term:'本',pronunciation:'hohn'},{term:'家',pronunciation:'ee-eh'},{term:'学校',pronunciation:'gahk-koh'},{term:'猫',pronunciation:'neh-koh'},{term:'犬',pronunciation:'ee-noo'}],
    [{term:'私は…です',pronunciation:'wah-tah-shee wah dess'},{term:'元気ですか？',pronunciation:'gen-kee dess kah'},{term:'元気です',pronunciation:'gen-kee dess'},{term:'お名前は？',pronunciation:'oh-nah-mah-eh wah'},{term:'私の名前は…',pronunciation:'wah-tah-shee noh nah-mah-eh wah'},{term:'好きです',pronunciation:'soo-kee dess'},{term:'わかりません',pronunciation:'wah-kah-ree-mah-sen'}],
    [{term:'りんご',pronunciation:'reen-goh'},{term:'パン',pronunciation:'pahn'},{term:'ごはん',pronunciation:'goh-hahn'},{term:'牛乳',pronunciation:'gyoo-nyoo'},{term:'コーヒー',pronunciation:'koh-hee'},{term:'お腹がすいた',pronunciation:'oh-nah-kah gah swee-tah'},{term:'お水をください',pronunciation:'oh-mee-zoo oh koo-dah-sigh'}],
    [{term:'どこ？',pronunciation:'doh-koh'},{term:'ここ',pronunciation:'koh-koh'},{term:'そこ',pronunciation:'soh-koh'},{term:'左',pronunciation:'hee-dah-ree'},{term:'右',pronunciation:'mee-gee'},{term:'今日',pronunciation:'kyoh'},{term:'明日',pronunciation:'ah-shee-tah'}],
  ],
  English: [
    [{term:'Hello',pronunciation:'heh-LOH'},{term:'Hello',pronunciation:'heh-LOH'},{term:'Yes',pronunciation:'yess'},{term:'No',pronunciation:'noh'},{term:'Please',pronunciation:'pleez'},{term:'Thank you',pronunciation:'THANK-yoo'},{term:'Goodbye',pronunciation:'good-BYE'}],
    [{term:'I',pronunciation:'eye'},{term:'You',pronunciation:'yoo'},{term:'We',pronunciation:'wee'},{term:'They',pronunciation:'thay'},{term:'Friend',pronunciation:'frend'},{term:'Family',pronunciation:'FAM-uh-lee'},{term:'Name',pronunciation:'naym'}],
    [{term:'One',pronunciation:'wun'},{term:'Two',pronunciation:'too'},{term:'Three',pronunciation:'three'},{term:'Four',pronunciation:'for'},{term:'Five',pronunciation:'fyve'},{term:'Six',pronunciation:'siks'},{term:'Seven',pronunciation:'SEV-en'}],
    [{term:'Water',pronunciation:'WAW-ter'},{term:'Food',pronunciation:'food'},{term:'Book',pronunciation:'book'},{term:'Home',pronunciation:'hohm'},{term:'School',pronunciation:'skool'},{term:'Cat',pronunciation:'kat'},{term:'Dog',pronunciation:'dawg'}],
    [{term:'I am…',pronunciation:'eye am'},{term:'How are you?',pronunciation:'how ar yoo'},{term:'I’m fine',pronunciation:'eyem fyn'},{term:'What is your name?',pronunciation:'wut iz yor naym'},{term:'My name is…',pronunciation:'my naym iz'},{term:'I like it',pronunciation:'eye lyk it'},{term:'I don’t understand',pronunciation:'eye dohnt un-der-STAND'}],
    [{term:'Apple',pronunciation:'AP-uhl'},{term:'Bread',pronunciation:'bred'},{term:'Rice',pronunciation:'ryce'},{term:'Milk',pronunciation:'milk'},{term:'Coffee',pronunciation:'KAW-fee'},{term:'I’m hungry',pronunciation:'eyem HUNG-gree'},{term:'Water, please',pronunciation:'WAW-ter pleez'}],
    [{term:'Where?',pronunciation:'wair'},{term:'Here',pronunciation:'heer'},{term:'There',pronunciation:'thair'},{term:'Left',pronunciation:'left'},{term:'Right',pronunciation:'ryte'},{term:'Today',pronunciation:'tuh-DAY'},{term:'Tomorrow',pronunciation:'tuh-MOR-oh'}],
  ],
}

function emptyCourse(): CourseProgress {
  return { completed: 0, xp: 0, correct: 0, answered: 0, lastPracticeDate: '' }
}
function makeInitialState(): AppState {
  return {
    language: 'Spanish', hearts: HEART_MAX, lastHeartAt: Date.now(),
    courses: Object.fromEntries(languages.map(language => [language.name, emptyCourse()])) as Record<string, CourseProgress>,
    character: 'panda', scarfColor: '#f4c64e', accessory: 'none',
  }
}

function useSavedState<T,>(key: string, fallback: T) {
  const [value, setValue] = useState<T>(() => {
    try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) as T : fallback } catch { return fallback }
  })
  useEffect(() => { localStorage.setItem(key, JSON.stringify(value)) }, [key, value])
  return [value, setValue] as const
}

function Panda({ mood = 'happy', small = false, character = 'panda', scarfColor = '#f4c64e', accessory = 'none' }: { mood?: string; small?: boolean; character?: string; scarfColor?: string; accessory?: string }) {
  const accessorySymbol = accessory === 'crown' ? '👑' : accessory === 'glasses' ? '🤓' : accessory === 'flower' ? '🌸' : ''
  return <div className={`panda panda-${character} ${small ? 'panda-small' : ''}`} aria-label={`Fluently ${character} mascot, ${mood}`}>
    <div className="panda-ear left" /><div className="panda-ear right" />
    <div className="panda-head"><div className="panda-mask left" /><div className="panda-mask right" />
      <div className="panda-eye left" /><div className="panda-eye right" /><div className="panda-nose" />
      <div className="panda-cheek left" /><div className="panda-cheek right" /><div className="panda-mouth" />
    </div>
    <div className="panda-scarf" style={{ background: scarfColor }} />
    {accessorySymbol && <span className={`panda-accessory accessory-${accessory}`}>{accessorySymbol}</span>}
  </div>
}

function makeQuestions(language: string, lessonIndex: number): Question[] {
  const sectionIndex = Math.floor(lessonIndex / LESSONS_PER_SECTION)
  const itemIndex = lessonIndex % LESSONS_PER_SECTION
  const terms = courseTerms[language] ?? courseTerms.Spanish
  const sectionTerms = terms[sectionIndex]
  const meanings = language === 'English' ? englishDefinitions[sectionIndex] : englishMeanings[sectionIndex]
  const kinds: QuestionKind[] = ['pronunciation', 'meaning', 'term']
  const start = (sectionIndex + itemIndex) % kinds.length
  const order = [...kinds.slice(start), ...kinds.slice(0, start)]

  return order.map((kind, questionNumber) => {
    const target = sectionTerms[itemIndex]
    const valueFor = (index: number) => kind === 'pronunciation'
      ? sectionTerms[index].pronunciation
      : kind === 'meaning'
        ? (language === 'English' ? englishDefinitions[sectionIndex][index] : englishMeanings[sectionIndex][index])
        : sectionTerms[index].term
    const unique: string[] = []
    for (let offset = 0; offset < LESSONS_PER_SECTION; offset++) {
      const index = (itemIndex + offset) % LESSONS_PER_SECTION
      const value = valueFor(index)
      if (!unique.includes(value)) unique.push(value)
      if (unique.length >= 4) break
    }
    const rotation = (sectionIndex + itemIndex + questionNumber) % unique.length
    const options = [...unique.slice(rotation), ...unique.slice(0, rotation)]
    const answer = valueFor(itemIndex)
    let prompt = ''
    let explain = ''
    if (kind === 'pronunciation') {
      prompt = `How is “${target.term}” pronounced?`
      explain = `A simple pronunciation guide is “${target.pronunciation}”. Listen, then try saying it aloud.`
    } else if (kind === 'meaning') {
      prompt = language === 'English' ? `Which clue best describes “${target.term}”?` : `What does “${target.term}” mean?`
      explain = language === 'English'
        ? `“${target.term}” is used for: ${englishDefinitions[sectionIndex][itemIndex].toLowerCase()}.`
        : `“${target.term}” means “${englishMeanings[sectionIndex][itemIndex]}” in English.`
    } else {
      prompt = language === 'English'
        ? `Which English word matches this clue: “${englishDefinitions[sectionIndex][itemIndex]}”?`
        : `Which ${language} word means “${englishMeanings[sectionIndex][itemIndex]}”?`
      explain = language === 'English'
        ? `The word is “${target.term}”: ${englishDefinitions[sectionIndex][itemIndex].toLowerCase()}.`
        : `“${target.term}” is the ${language} word or phrase for “${englishMeanings[sectionIndex][itemIndex]}”.`
    }
    return { prompt, options, answer, explain, say: target.term }
  })
}

function App() {
  const [page, setPage] = useState<Page>('Home')
  const [showIntro, setShowIntro] = useState(true)
  useEffect(() => { const timer = window.setTimeout(() => setShowIntro(false), 3600); return () => window.clearTimeout(timer) }, [])
  const [state, setState] = useSavedState<AppState>('fluently-progress-v3', makeInitialState())
  const [dark, setDark] = useSavedState('fluently-dark-v1', false)
  const [selectedAnswer, setSelectedAnswer] = useState('')
  const [questionIndex, setQuestionIndex] = useState(0)
  const [activeLessonIndex, setActiveLessonIndex] = useState(0)
  const [lessonActive, setLessonActive] = useState(false)
  const [checked, setChecked] = useState(false)
  const [correct, setCorrect] = useState(false)
  const [showLanguage, setShowLanguage] = useState(false)
  const [showCelebration, setShowCelebration] = useState(false)
  const [notice, setNotice] = useState('')
  const [clock, setClock] = useState(Date.now())

  useEffect(() => {
    const timer = window.setTimeout(() => setNotice(''), 3000)
    return () => window.clearTimeout(timer)
  }, [notice])
  useEffect(() => {
    const timer = window.setInterval(() => {
      const now = Date.now()
      setClock(now)
      setState(current => {
        if (current.hearts >= HEART_MAX) return current
        const gained = Math.floor((now - current.lastHeartAt) / HEART_INTERVAL)
        if (gained < 1) return current
        const hearts = Math.min(HEART_MAX, current.hearts + gained)
        return { ...current, hearts, lastHeartAt: hearts === HEART_MAX ? now : current.lastHeartAt + gained * HEART_INTERVAL }
      })
    }, 15000)
    return () => window.clearInterval(timer)
  }, [setState])

  const lang = languages.find(language => language.name === state.language) ?? languages[0]
  const course = state.courses[state.language] ?? emptyCourse()
  const lessonQuestions = useMemo(() => makeQuestions(state.language, activeLessonIndex), [state.language, activeLessonIndex])
  const q = lessonQuestions[questionIndex] ?? lessonQuestions[0]
  const sectionIndex = Math.floor(activeLessonIndex / LESSONS_PER_SECTION)
  const lessonInSection = activeLessonIndex % LESSONS_PER_SECTION
  const activeSection = sections[sectionIndex] ?? sections[0]
  const progress = Math.min(100, Math.round(course.completed / TOTAL_LESSONS * 100))
  const heartsRemainingMs = state.hearts >= HEART_MAX ? 0 : Math.max(0, HEART_INTERVAL - (clock - state.lastHeartAt))
  const heartTimer = `${Math.floor(heartsRemainingMs / 60000)}:${String(Math.floor((heartsRemainingMs % 60000) / 1000)).padStart(2, '0')}`

  const nav: { label: Page; icon: typeof Home }[] = [
    { label: 'Home', icon: Home }, { label: 'Learn', icon: Map },
    { label: 'Progress', icon: BarChart3 }, { label: 'Profile', icon: UserRound }, { label: 'Settings', icon: Settings },
  ]
  const showNotice = (message: string) => setNotice(message)

  function startLesson(index = Math.min(course.completed, TOTAL_LESSONS - 1)) {
    if (index > course.completed) { showNotice('Finish the previous lesson to unlock this one.'); return }
    if (state.hearts <= 0) { showNotice(`You’re out of hearts. Your next heart arrives in ${heartTimer}.`); return }
    setActiveLessonIndex(index)
    setQuestionIndex(0)
    setSelectedAnswer('')
    setChecked(false)
    setCorrect(false)
    setShowCelebration(false)
    setLessonActive(true)
    setPage('Learn')
  }

  function check() {
    if (!selectedAnswer) { showNotice('Choose an answer first!'); return }
    if (state.hearts <= 0) { showNotice(`No hearts left. A heart recharges in ${heartTimer}.`); return }
    const isRight = selectedAnswer === q.answer
    setCorrect(isRight)
    setChecked(true)
    setState(current => {
      const progressForLanguage = current.courses[current.language] ?? emptyCourse()
      const nextCourse = {
        ...progressForLanguage,
        xp: progressForLanguage.xp + (isRight ? 5 : 0),
        correct: progressForLanguage.correct + (isRight ? 1 : 0),
        answered: progressForLanguage.answered + 1,
      }
      const hearts = isRight ? current.hearts : Math.max(0, current.hearts - 1)
      return {
        ...current,
        hearts,
        lastHeartAt: !isRight && current.hearts === HEART_MAX ? Date.now() : current.lastHeartAt,
        courses: { ...current.courses, [current.language]: nextCourse },
      }
    })
  }

  function nextQuestion() {
    if (questionIndex < lessonQuestions.length - 1) {
      setQuestionIndex(index => index + 1)
      setSelectedAnswer('')
      setChecked(false)
      setCorrect(false)
      return
    }
    const today = new Date().toISOString().slice(0, 10)
    setState(current => {
      const oldCourse = current.courses[current.language] ?? emptyCourse()
      const nextCourse = {
        ...oldCourse,
        completed: Math.max(oldCourse.completed, activeLessonIndex + 1),
        xp: oldCourse.xp + 15,
        lastPracticeDate: today,
      }
      return { ...current, courses: { ...current.courses, [current.language]: nextCourse } }
    })
    setLessonActive(false)
    setShowCelebration(true)
  }

  function chooseLanguage(languageName: string) {
    setState(current => ({ ...current, language: languageName }))
    setShowLanguage(false)
    setShowCelebration(false)
    setLessonActive(false)
    setSelectedAnswer('')
    setQuestionIndex(0)
    setPage('Home')
    showNotice(`${languageName} course selected! Its lessons and progress are now shown.`)
  }

  function playPronunciation(text: string) {
    if (!('speechSynthesis' in window)) { showNotice('Speech playback is not supported by this browser.'); return }
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = lang.speechCode
    window.speechSynthesis.cancel()
    window.speechSynthesis.speak(utterance)
  }

  const learningPath = <div className="learning-path-sections">
    {sections.map((section, unitIndex) => {
      const unitStart = unitIndex * LESSONS_PER_SECTION
      const completedInUnit = Math.max(0, Math.min(LESSONS_PER_SECTION, course.completed - unitStart))
      const unitPercent = Math.round(completedInUnit / LESSONS_PER_SECTION * 100)
      return <section className="path-card unit-path-card" key={section.title}>
        <div className="path-top unit-heading-row">
          <div className="unit-badge">UNIT {String(unitIndex + 1).padStart(2, '0')}</div>
          <div className="unit-heading-copy"><h3>{section.icon} {section.title}</h3><p>{section.subtitle}</p></div>
          <div className="unit-progress"><b>{unitPercent}%</b><div className="mini-track"><span style={{ width: `${unitPercent}%` }} /></div><small>{completedInUnit}/7 lessons</small></div>
        </div>
        <div className="lesson-path lesson-path-vertical">
          {section.titles.map((title, index) => {
            const lessonIndex = unitStart + index
            const isComplete = lessonIndex < course.completed
            const isLocked = lessonIndex > course.completed
            const isCurrent = lessonIndex === course.completed
            return <button
              key={`${state.language}-${title}-${index}`}
              className={`lesson-node lesson-node-vertical ${isLocked ? 'locked' : ''} ${isCurrent ? 'node-current' : ''} ${isComplete ? 'node-complete' : ''}`}
              style={{ animationDelay: `${index * 28}ms` }}
              onClick={() => startLesson(lessonIndex)}
            >
              <span className="node-icon">{isComplete ? <Check size={20} /> : isLocked ? <LockKeyhole size={17} /> : <span>{index === 0 ? '✨' : String(index + 1).padStart(2, '0')}</span>}</span>
              <span className="node-copy"><span className="node-title">{title}</span><span className="node-subtitle">{section.subtitles[index]}</span></span>
              <span className={`node-status ${isComplete ? 'status-done' : isCurrent ? 'status-start' : ''}`}>{isComplete ? 'DONE' : isCurrent ? 'START' : 'LOCKED'}</span>
              <ChevronRight className="node-chevron" size={17} />
            </button>
          })}
        </div>
      </section>
    })}
  </div>

  return <div className={dark ? 'app dark' : 'app'}>
    {showIntro && <div className="intro-splash" role="status" aria-label="Welcome to Fluently"><div className="intro-glow glow-one"/><div className="intro-glow glow-two"/><div className="intro-stars">✦ <span>✧</span> ✦</div><div className="intro-mascot-wrap"><div className="intro-orbit"/><div className="intro-mascot"><Panda character={state.character} scarfColor={state.scarfColor} accessory={state.accessory}/></div><div className="intro-pop pop-left">👋</div><div className="intro-pop pop-right">✨</div></div><div className="intro-wordmark">fluently<span>.</span></div><div className="intro-name">Meet <b>Gub</b>!</div><p className="intro-caption">Your little language-learning buddy.</p><div className="intro-loading"><span/></div></div>}

    <aside className="sidebar">
      <button className="brand" onClick={() => setPage('Home')} aria-label="Fluently home"><span className="brand-mark"><Sparkles size={20}/></span><span>fluently<span className="brand-dot">.</span></span></button>
      <div className="side-course-label">YOUR LEARNING SPACE</div>
      <button className="course-switch" onClick={() => setShowLanguage(true)}><span className="flag">{lang.flag}</span><span className="course-switch-copy"><b>{lang.name}</b><small>{course.completed}/49 lessons</small></span><ChevronRight size={16}/></button>
      <nav className="main-nav">{nav.map(item => { const Icon = item.icon; return <button key={item.label} className={`nav-item ${page === item.label ? 'active' : ''}`} onClick={() => { if (item.label === 'Learn') { setPage('Learn'); setLessonActive(false); setShowCelebration(false) } else { setPage(item.label); setLessonActive(false); setShowCelebration(false) } }}><Icon size={19}/><span>{item.label}</span></button> })}</nav>
      <div className="sidebar-bottom"><div className="sidebar-heart-note"><Heart size={16} fill="currentColor"/><div><b>{state.hearts}/5 hearts</b><small>{state.hearts === HEART_MAX ? 'All charged up!' : `Next heart in ${heartTimer}`}</small></div></div><div className="sidebar-footer">Learn at your own pace.<br/><b>Every word counts. ✨</b></div></div>
    </aside>

    <main className="main">
      <header className="topbar"><div className="mobile-brand"><span className="brand-mark"><Sparkles size={18}/></span> fluently<span className="brand-dot">.</span></div><div className="topbar-spacer"/><div className="stat-chip"><Zap size={18} className="xp-icon"/><b>{course.xp}</b><span>XP · {lang.name}</span></div><div className="stat-chip heart-stat"><span className="heart-icons">{Array.from({length: HEART_MAX}, (_, index) => <Heart key={index} size={14} fill={index < state.hearts ? 'currentColor' : 'none'} />)}</span><b>{state.hearts}/5</b><span>{state.hearts === HEART_MAX ? 'full' : `+1 in ${heartTimer}`}</span></div><button className="avatar-button" onClick={() => setPage('Profile')} aria-label="Customize your character"><Panda small character={state.character} scarfColor={state.scarfColor} accessory={state.accessory}/></button></header>

      {page === 'Home' && <div className="page-content home-content">
        <div className="welcome-row"><div><div className="eyebrow"><Sparkles size={14}/> YOUR DAILY ADVENTURE</div><h1>Ready to make<br/><span>some progress?</span></h1><p className="muted">Small steps. Big “I can actually speak this” energy.</p><button className="primary-button" onClick={() => startLesson()}><Play size={17} fill="currentColor"/> {course.completed >= TOTAL_LESSONS ? 'Review a lesson' : 'Continue learning'} <ChevronRight size={17}/></button><div className="welcome-mini-stats"><span><BookOpen size={15}/> {course.completed}/49 lessons</span><span><Flame size={15}/> {progress}% complete</span></div></div><div className="hero-art"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="hero-spark spark-one">✦</div><div className="hero-spark spark-two">✧</div><Panda character={state.character} scarfColor={state.scarfColor} accessory={state.accessory}/><div className="speech-bubble">{lang.greeting} <span>👋</span></div><div className="float-card"><span>⚡</span><div><b>{course.xp} XP</b><small>and counting!</small></div></div></div></div>
        <div className="section-heading"><div><h2>Your learning path</h2><p>7 units · 7 lessons in every unit · 49 lessons per language.</p></div><button className="text-button" onClick={() => setPage('Learn')}>Open learning map <ChevronRight size={16}/></button></div>
        {learningPath}
        <div className="bottom-grid"><div className="daily-card"><div className="card-title-row"><div><div className="eyebrow">DAILY MISSION</div><h3>A tiny bit every day.</h3></div><span className="mission-icon">🎯</span></div><p>Complete one short lesson, practise pronunciation, and build your confidence.</p><div className="mission-progress"><div className="mission-track"><span style={{width:`${Math.min(100, course.xp % 50 / 30 * 100)}%`}}/></div><b>{course.xp % 50}/30 XP</b></div><button className="outline-button" onClick={() => startLesson()}>Take a quick lesson <ChevronRight size={16}/></button></div><div className="tip-card"><div className="tip-top"><span className="tip-icon"><BookOpen size={19}/></span><span className="eyebrow">GUB’S LITTLE TIP</span></div><h3>Say it out loud.</h3><p>Listen to the pronunciation, then repeat it slowly. You can replay it as many times as you like.</p><div className="tip-panda"><Panda small character={state.character} scarfColor={state.scarfColor} accessory={state.accessory}/><span>You’ve got this!</span></div></div></div>
      </div>}

      {page === 'Learn' && !lessonActive && !showCelebration && <div className="page-content learning-map-page"><div className="eyebrow"><Map size={14}/> YOUR COURSE MAP</div><h1>One small step at a time.</h1><p className="muted">You’re learning {lang.name}. Each unit has seven lessons, starting with the very basics and moving towards useful sentences.</p><div className="map-summary"><span>{lang.flag}</span><div><b>{lang.name} beginner path</b><small>{course.completed} of {TOTAL_LESSONS} lessons complete</small></div><div className="big-track"><span style={{width:`${progress}%`}}/></div><b>{progress}%</b></div>{learningPath}</div>}

      {page === 'Learn' && lessonActive && !showCelebration && q && <div className="page-content lesson-page">
        <button className="back-link" onClick={() => {setLessonActive(false);setPage('Home')}}>✕ Exit lesson</button>
        <div className="lesson-progress-row"><div className="lesson-track"><span style={{width:`${(questionIndex + (checked ? 1 : 0))/lessonQuestions.length*100}%`}}/></div><span>{questionIndex + 1} of {lessonQuestions.length}</span><button className="icon-button" onClick={() => {setLessonActive(false);setPage('Home')}} aria-label="Exit lesson"><X size={18}/></button></div>
        <div className="lesson-heading"><div className="lesson-emoji">{activeSection.icon}</div><div><div className="eyebrow">{lang.flag} {lang.name.toUpperCase()} · UNIT {sectionIndex + 1} · LESSON {lessonInSection + 1}</div><h1>{activeSection.titles[lessonInSection]}</h1><p>Listen, choose the answer, and practise at your own pace.</p></div></div>
        <div className="question-card lesson-question-card"><div className="question-count">QUESTION {questionIndex + 1} OF 3</div><h2>{q.prompt}</h2><button className="listen-button" onClick={() => playPronunciation(q.say)}><Volume2 size={17}/> Listen to pronunciation <span>↗</span></button><div className="answer-options">{q.options.map((option, index) => <button key={`${option}-${index}`} disabled={checked} className={`answer-option ${selectedAnswer === option ? 'selected' : ''} ${checked && option === q.answer ? 'right' : ''} ${checked && selectedAnswer === option && !correct ? 'wrong' : ''}`} onClick={() => setSelectedAnswer(option)}><span className="option-letter">{String.fromCharCode(65 + index)}</span>{option}{checked && option === q.answer && <Check size={18} className="answer-check"/>}</button>)}</div>
          {checked && <div className={`feedback ${correct ? 'feedback-good' : 'feedback-bad'}`}><b>{correct ? '✨ Lovely work! That’s right!' : 'Not quite — you’re still learning!'}</b><p>{q.explain}</p></div>}
          {state.hearts <= 0 && <div className="heart-empty-note"><Heart size={17} fill="currentColor"/><span>You’re out of hearts. The next one arrives in <b>{heartTimer}</b>. You can still listen and review this word.</span></div>}
          <div className="question-footer"><span className="lesson-heart-count"><span className="heart-icons">{Array.from({length: HEART_MAX}, (_, index) => <Heart key={index} size={15} fill={index < state.hearts ? 'currentColor' : 'none'} />)}</span><small>{state.hearts < HEART_MAX ? `+1 in ${heartTimer}` : '5 hearts full'}</small></span>{!checked ? <button className="primary-button" onClick={check} disabled={state.hearts <= 0}>Check answer <ChevronRight size={17}/></button> : <button className="primary-button" onClick={nextQuestion}>{questionIndex === lessonQuestions.length - 1 ? 'Finish lesson' : 'Continue'} <ChevronRight size={17}/></button>}</div>
        </div><div className="lesson-help"><CircleHelp size={17}/><span>Need a hand? Take your time — learning is a process.</span><button onClick={() => showNotice(`Hint: ${q.explain}`)}>Get a hint</button></div>
      </div>}

      {page === 'Learn' && showCelebration && <div className="page-content celebration-page"><div className="celebration-card"><div className="celebration-confetti"><span>✦</span><span>✧</span><span>✦</span><span>✧</span><span>✦</span><span>✧</span><span>✦</span><span>✧</span></div><div className="celebration-mascot"><Panda character={state.character} scarfColor={state.scarfColor} accessory={state.accessory}/><span className="celebration-bubble">Yay!</span></div><div className="eyebrow"><Award size={14}/> {activeLessonIndex % LESSONS_PER_SECTION === LESSONS_PER_SECTION - 1 ? 'UNIT MILESTONE' : 'LITTLE WIN UNLOCKED'}</div><h1>{activeLessonIndex % LESSONS_PER_SECTION === LESSONS_PER_SECTION - 1 ? 'Unit complete!' : 'Lesson complete!'}</h1><p>{activeLessonIndex % LESSONS_PER_SECTION === LESSONS_PER_SECTION - 1 ? `You finished ${activeSection.title}. Your next unit is waiting whenever you’re ready.` : `You took another step in ${lang.name}. Keep the streak of learning going!`}</p><div className="celebration-rewards"><span><Zap size={17}/> +15 bonus XP</span><span><Check size={17}/> {Math.max(course.completed, activeLessonIndex + 1)}/49 lessons</span></div><button className="primary-button" onClick={() => {setShowCelebration(false);setLessonActive(false);setPage('Home');showNotice('Nice work! Your learning path has been updated.')}}>Back to my path <ChevronRight size={17}/></button><button className="text-button celebration-review" onClick={() => startLesson(Math.min(activeLessonIndex + 1, TOTAL_LESSONS - 1))}>{activeLessonIndex + 1 < TOTAL_LESSONS ? 'Try the next lesson' : 'Review a lesson'} <ChevronRight size={16}/></button></div></div>}

      {page === 'Progress' && <div className="page-content inner-page"><div className="eyebrow"><BarChart3 size={14}/> YOUR JOURNEY SO FAR</div><h1>Look how far you’ve come.</h1><p className="muted">Every little practice session counts, and each language has its own progress.</p><div className="metric-grid"><div className="metric-card"><span className="metric-icon orange"><Zap size={20}/></span><b>{course.xp}</b><small>{lang.name} XP</small></div><div className="metric-card"><span className="metric-icon pink"><BookOpen size={20}/></span><b>{course.completed}/49</b><small>Lessons completed</small></div><div className="metric-card"><span className="metric-icon green"><Target size={20}/></span><b>{course.answered ? Math.round(course.correct / course.answered * 100) : 0}%</b><small>Answer accuracy</small></div><div className="metric-card"><span className="metric-icon purple"><Flame size={20}/></span><b>{state.hearts}/5</b><small>Hearts available</small></div></div><div className="progress-detail-card"><h3>Your {lang.name} course progress</h3><div className="course-progress-line"><span>{lang.flag} {lang.name}</span><b>{progress}%</b></div><div className="big-track"><span style={{width:`${progress}%`}}/></div><p>You’ve completed {course.completed} out of {TOTAL_LESSONS} lessons in this course.</p></div><div className="all-course-progress"><h3>Your other courses</h3>{languages.filter(language => language.name !== state.language).map(language => { const p = state.courses[language.name] ?? emptyCourse(); return <button className="course-progress-choice" key={language.name} onClick={() => chooseLanguage(language.name)}><span className="course-progress-flag">{language.flag}</span><span className="course-progress-copy"><b>{language.name}</b><small>{p.completed}/49 lessons · {p.xp} XP</small><span className="big-track"><span style={{width:`${Math.round(p.completed / TOTAL_LESSONS * 100)}%`}}/></span></span><ChevronRight size={16}/></button> })}</div></div>}

      {page === 'Profile' && <div className="page-content inner-page"><div className="profile-hero"><div className="profile-mascot"><Panda character={state.character} scarfColor={state.scarfColor} accessory={state.accessory}/></div><div><div className="eyebrow">YOUR FLUENTLY PROFILE</div><h1>Make Gub yours.</h1><p className="muted">Pick a character, scarf colour, and accessory. Your buddy will follow you around the app.</p><div className="profile-badges"><span>📚 {course.completed} lessons</span><span>⚡ {course.xp} XP</span><span>{lang.flag} {lang.name}</span></div></div></div>
        <div className="progress-detail-card customization-card"><h3><WandSparkles size={19}/> Character customization</h3><p className="muted">Choose your favourite look. Changes are saved on this device.</p><div className="customization-group"><b>1. Choose your buddy</b><div className="choice-grid character-choices">{[{id:'panda',label:'Gub the panda',emoji:'🦊'},{id:'cat',label:'Kitty',emoji:'🐱'},{id:'fox',label:'Foxy',emoji:'🦊'},{id:'bunny',label:'Bun-bun',emoji:'🐰'},{id:'koala',label:'Koala',emoji:'🐨'}].map(choice => <button key={choice.id} className={`choice-chip ${state.character === choice.id ? 'choice-selected' : ''}`} onClick={() => setState(current => ({...current, character:choice.id}))}><span>{choice.emoji}</span><b>{choice.label}</b>{state.character === choice.id && <Check size={15}/>}</button>)}</div></div>
          <div className="customization-group"><b>2. Pick a scarf colour</b><div className="scarf-colors">{[{name:'Sunshine',color:'#f4c64e'},{name:'Bubblegum',color:'#f18ab4'},{name:'Lavender',color:'#a99aed'},{name:'Mint',color:'#70cbaa'},{name:'Sky',color:'#76bde9'},{name:'Berry',color:'#b7557c'},{name:'Classic',color:'#f4f0e8'}].map(option => <button key={option.color} title={option.name} aria-label={`${option.name} scarf`} className={`scarf-swatch ${state.scarfColor === option.color ? 'swatch-selected' : ''}`} style={{background:option.color}} onClick={() => setState(current => ({...current, scarfColor:option.color}))}>{state.scarfColor === option.color && <Check size={16}/>}</button>)}</div></div>
          <div className="customization-group"><b>3. Add an accessory</b><div className="choice-grid accessory-choices">{[{id:'none',label:'No accessory',emoji:'✨'},{id:'crown',label:'Crown',emoji:'👑'},{id:'glasses',label:'Glasses',emoji:'🤓'},{id:'flower',label:'Flower',emoji:'🌸'}].map(option => <button key={option.id} className={`choice-chip ${state.accessory === option.id ? 'choice-selected' : ''}`} onClick={() => setState(current => ({...current, accessory:option.id}))}><span>{option.emoji}</span><b>{option.label}</b>{state.accessory === option.id && <Check size={15}/>}</button>)}</div></div>
          <div className="customization-preview"><Panda character={state.character} scarfColor={state.scarfColor} accessory={state.accessory}/><div><b>Looking good!</b><small>Your buddy is ready for your next lesson.</small></div></div>
        </div>
        <div className="progress-detail-card"><h3><Award size={18}/> Achievements</h3><div className="achievement-list"><div className={`achievement ${course.completed >= 1 ? 'achievement-unlocked' : ''}`}><span>🌱</span><div><b>First steps</b><small>Complete your first lesson</small></div>{course.completed >= 1 ? <Check size={17}/> : <span className="locked-label">LOCKED</span>}</div><div className={`achievement ${course.completed >= 7 ? 'achievement-unlocked' : ''}`}><span>🌈</span><div><b>Unit explorer</b><small>Complete your first unit</small></div>{course.completed >= 7 ? <Check size={17}/> : <span className="locked-label">IN PROGRESS</span>}</div><div className={`achievement ${course.answered > 0 && course.correct / course.answered >= .9 ? 'achievement-unlocked' : ''}`}><span>🎯</span><div><b>Sharp shooter</b><small>Reach 90% accuracy</small></div>{course.answered > 0 && course.correct / course.answered >= .9 ? <Check size={17}/> : <span className="locked-label">IN PROGRESS</span>}</div></div></div>
      </div>}

      {page === 'Settings' && <div className="page-content inner-page"><div className="eyebrow"><Settings size={14}/> MAKE IT YOURS</div><h1>Your settings</h1><p className="muted">A few little things to make Fluently feel like you.</p><div className="settings-card"><div className="setting-row"><div className="setting-icon"><Languages size={20}/></div><div className="setting-copy"><b>Learning language</b><small>Choose a course with its own lessons and saved progress.</small></div><button className="outline-button" onClick={() => setShowLanguage(true)}>{lang.flag} {lang.name} <ChevronRight size={15}/></button></div><div className="setting-row"><div className="setting-icon"><Clock3 size={20}/></div><div className="setting-copy"><b>Heart recharge</b><small>Maximum 5 hearts. You regain 1 heart every hour.</small></div><span className="heart-setting-status">{state.hearts === HEART_MAX ? 'Full' : `${state.hearts}/5 · ${heartTimer}`}</span></div><div className="setting-row"><div className="setting-icon"><Sparkles size={20}/></div><div className="setting-copy"><b>Dark mode</b><small>Switch to a darker study space.</small></div><button className={`toggle ${dark ? 'on' : ''}`} onClick={() => setDark(value => !value)} aria-label="Toggle dark mode"><span/></button></div><div className="setting-row"><div className="setting-icon"><RotateCcw size={20}/></div><div className="setting-copy"><b>Reset demo progress</b><small>Reset all course progress, hearts, and your character on this device.</small></div><button className="outline-button danger-button" onClick={() => { if (confirm('Reset all your Fluently progress?')) { setState(makeInitialState()); setPage('Home'); setLessonActive(false); setShowCelebration(false); showNotice('Demo progress reset.') } }}>Reset progress</button></div></div><div className="privacy-note"><ShieldCheck size={18}/><div><b>Your demo data stays on this device.</b><p>This prototype uses browser storage. Course content and progress are local; accounts and cloud sync are not included.</p></div></div></div>}

      <footer className="page-footer"><span>fluently<span className="brand-dot">.</span></span><span>Made for curious minds, one word at a time.</span></footer>
    </main>

    {showLanguage && <div className="modal-backdrop" onClick={() => setShowLanguage(false)}><div className="language-modal" onClick={(event: { stopPropagation: () => void }) => event.stopPropagation()}><button className="modal-close" onClick={() => setShowLanguage(false)}><X size={18}/></button><div className="eyebrow"><Languages size={14}/> CHOOSE YOUR ADVENTURE</div><h2>What do you want to learn?</h2><p className="muted">Each language has its own words, pronunciation practice, and progress.</p><div className="language-list">{languages.map(item => { const itemProgress = state.courses[item.name] ?? emptyCourse(); return <button key={item.name} className={`language-option ${state.language === item.name ? 'language-selected' : ''}`} onClick={() => chooseLanguage(item.name)}><span>{item.flag}</span><div><b>{item.name}</b><small>{item.course} · {itemProgress.completed}/49 lessons</small></div>{state.language === item.name && <Check size={18}/>}</button> })}</div></div></div>}
    {notice && <div className="toast"><Sparkles size={17}/>{notice}</div>}
  </div>
}

export default App
